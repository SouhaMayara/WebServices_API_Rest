create definer = admin@`%` view structure_status_doss_subquery as
select `interface`.`etat_dossier`.`id`                                                   AS `id_statut`,
       `interface`.`etat_dossier`.`etat`                                                 AS `statut`,
       `interface`.`class_etats`.`libele`                                                AS `etats`,
       `interface`.`etat_dossier`.`id_p`                                                 AS `parent`,
       `interface`.`etat_dossier`.`categorie`                                            AS `id_categorie`,
       `interface`.`catergorieStatusDoss`.`libele`                                       AS `categorie`,
       `interface`.`etat_dossier`.`visa`                                                 AS `visa`,
       ifnull(`interface`.`etat_dossier`.`visa`, `interface`.`etat_dossier`.`categorie`) AS `id_service`,
       `interface`.`etat_dossier`.`classe`                                               AS `id_classe`,
       `interface`.`class_etats`.`color`                                                 AS `couleur`,
       `interface`.`class_etats`.`icon`                                                  AS `icone`
from ((`interface`.`etat_dossier` left join `interface`.`catergorieStatusDoss` on (
        `interface`.`etat_dossier`.`categorie` = `interface`.`catergorieStatusDoss`.`id`))
         left join `interface`.`class_etats` on (`interface`.`etat_dossier`.`classe` = `interface`.`class_etats`.`id`))
order by ifnull(`interface`.`etat_dossier`.`visa`, `interface`.`etat_dossier`.`categorie`);

