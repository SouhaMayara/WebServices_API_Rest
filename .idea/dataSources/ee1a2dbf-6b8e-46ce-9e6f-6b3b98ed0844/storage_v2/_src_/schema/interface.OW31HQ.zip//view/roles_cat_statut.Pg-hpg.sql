create definer = admin@`%` view roles_cat_statut as
select `interface`.`users`.`id`                                   AS `users_id`,
       `interface`.`roles`.`role`                                 AS `roles_libelle`,
       group_concat(concat(`interface`.`catergorieStatusOpp`.`id`, `interface`.`catergorieStatusOpp`.`color`,
                           `nouv_users_cat`.`sup`) separator '|') AS `categorie_libelle_color`
from (((`interface`.`users` left join `interface`.`roles` on (`interface`.`users`.`role` = `interface`.`roles`.`id`)) left join `interface`.`nouv_users_cat` on (`nouv_users_cat`.`id_user` = `interface`.`users`.`id`))
         left join `interface`.`catergorieStatusOpp`
                   on (`nouv_users_cat`.`category` = `interface`.`catergorieStatusOpp`.`id`))
group by `interface`.`users`.`id`;

