create definer = admin@`%` view view_produit_catalogue as
select `interface`.`contrat`.`type`                      AS `type`,
       `interface`.`cmp`.`denomination`                  AS `denomination`,
       `interface`.`produit_sante`.`id`                  AS `id`,
       `interface`.`produit_sante`.`logo_produit`        AS `logo_produit`,
       `interface`.`produit_sante`.`nom_produit`         AS `nom_produit`,
       `interface`.`produit_sante`.`option`              AS `option`,
       `interface`.`produit_sante`.`game`                AS `game`,
       `interface`.`produit_sante`.`renfort`             AS `renfort`,
       `interface`.`produit_sante`.`id_campagne`         AS `id_campagne`,
       `interface`.`produit_sante`.`url_tarification`    AS `url_tarification`,
       `interface`.`produit_sante`.`pro`                 AS `pro`,
       `interface`.`produit_sante`.`support_commercial`  AS `support_commercial`,
       `interface`.`produit_sante`.`tableaux_garanties`  AS `tableaux_garanties`,
       `interface`.`produit_sante`.`formulaire_adhesion` AS `formulaire_adhesion`,
       `interface`.`produit_sante`.`note`                AS `note`,
       `interface`.`produit_sante`.`id_contrat`          AS `id_contrat`,
       `interface`.`produit_sante`.`extension_garantie`  AS `extension_garantie`,
       `interface`.`produit_sante`.`code_bareme`         AS `code_bareme`,
       `interface`.`game_prod`.`nom`                     AS `nom_game`
from (((`interface`.`produit_sante` join `interface`.`contrat` on (`interface`.`produit_sante`.`id_contrat` = `interface`.`contrat`.`id`)) join `interface`.`cmp` on (`interface`.`produit_sante`.`id_campagne` = `interface`.`cmp`.`siren`))
         left join `interface`.`game_prod` on (`interface`.`produit_sante`.`game` = `interface`.`game_prod`.`id`));

