create definer = admin@`%` view roles_cat_statut_doss as
select `interface`.`users`.`id`                                                                                   AS `users_id`,
       `interface`.`roles`.`role`                                                                                 AS `role_libele`,
       group_concat(concat(`interface`.`catergorieStatusDoss`.`id`, `interface`.`catergorieStatusDoss`.`icon`,
                           `nouv_user_cat_doss`.`sup`, `interface`.`catergorieStatusDoss`.`ordre`) separator
                    '|')                                                                                          AS `categorie_libelle_icon`
from (((`interface`.`users` left join `interface`.`roles` on (`interface`.`users`.`role` = `interface`.`roles`.`id`)) left join `interface`.`nouv_user_cat_doss` on (`nouv_user_cat_doss`.`id_user` = `interface`.`users`.`id`))
         left join `interface`.`catergorieStatusDoss`
                   on (`nouv_user_cat_doss`.`category` = `interface`.`catergorieStatusDoss`.`id`))
group by `interface`.`users`.`id`;

