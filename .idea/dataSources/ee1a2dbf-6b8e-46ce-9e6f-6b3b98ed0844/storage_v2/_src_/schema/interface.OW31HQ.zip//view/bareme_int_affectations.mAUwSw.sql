create definer = `nginx-sodedif`@`%` view bareme_int_affectations as select distinct `temp`.`id_user`           AS `id_user`,
                                                                                     `temp`.`groupe_commission` AS `id_group`,
                                                                                     `temp`.`code_group`        AS `code_group`
                                                                     from (select `interface`.`users`.`id`                AS `id_user`,
                                                                                  `interface`.`users`.`groupe_commission` AS `groupe_commission`,
                                                                                  `interface`.`groupe_commission`.`code`  AS `code_group`
                                                                           from (`interface`.`users`
                                                                                    left join `interface`.`groupe_commission`
                                                                                              on (`interface`.`users`.`groupe_commission` =
                                                                                                  `interface`.`groupe_commission`.`id`))
                                                                           where `interface`.`users`.`code` =
                                                                                 (select if(
                                                                                                     `interface`.`affaire`.`code_prod` is not null and
                                                                                                     `interface`.`affaire`.`code_prod` <> '',
                                                                                                     `interface`.`affaire`.`code_prod`,
                                                                                                     `interface`.`users`.`code`) AS `code`
                                                                                  from ((`interface`.`affaire` left join `interface`.`opportunite` on (`interface`.`affaire`.`id_opp` = `interface`.`opportunite`.`id`))
                                                                                           left join `interface`.`users`
                                                                                                     on (`interface`.`users`.`id` = `interface`.`opportunite`.`commerciaux_id`))
                                                                                  where `interface`.`affaire`.`id` = '351381_2019-06-19-21-19-56')
                                                                           union all
                                                                           select `interface`.`users`.`id`                AS `id_user`,
                                                                                  `interface`.`users`.`groupe_commission` AS `id_group`,
                                                                                  `interface`.`groupe_commission`.`code`  AS `code_group`
                                                                           from ((`interface`.`binome_affaire` left join `interface`.`users` on (
                                                                                   `interface`.`binome_affaire`.`id_commercieaux` =
                                                                                   `interface`.`users`.`id`))
                                                                                    left join `interface`.`groupe_commission`
                                                                                              on (`interface`.`users`.`groupe_commission` =
                                                                                                  `interface`.`groupe_commission`.`id`))
                                                                           where `interface`.`binome_affaire`.`id_affaire` =
                                                                                 '351381_2019-06-19-21-19-56'
                                                                           union all
                                                                           select `interface`.`users`.`id`                AS `id_user`,
                                                                                  `interface`.`users`.`groupe_commission` AS `id_group`,
                                                                                  `interface`.`groupe_commission`.`code`  AS `code_group`
                                                                           from (((`interface`.`affaire` left join `interface`.`opportunite` on (`interface`.`affaire`.`id_opp` = `interface`.`opportunite`.`id`)) left join `interface`.`users` on (`interface`.`users`.`id` = `interface`.`opportunite`.`users_id`))
                                                                                    left join `interface`.`groupe_commission`
                                                                                              on (`interface`.`users`.`groupe_commission` =
                                                                                                  `interface`.`groupe_commission`.`id`))
                                                                           where `interface`.`affaire`.`id` = '351381_2019-06-19-21-19-56'
                                                                             and `interface`.`users`.`groupe_commission` in (16, 17)) `temp`
                                                                     where `temp`.`id_user` <> 579
                                                                     union all
                                                                     select `tab_actions`.`id_user`    AS `id_user`,
                                                                            `tab_actions`.`id_group`   AS `id_group`,
                                                                            `tab_actions`.`code_group` AS `code_group`
                                                                     from (select `interface`.`users`.`id`                AS `id_user`,
                                                                                  `interface`.`users`.`groupe_commission` AS `id_group`,
                                                                                  `interface`.`groupe_commission`.`code`  AS `code_group`
                                                                           from (((((`interface`.`affaire` left join `interface`.`opportunite` on (`interface`.`affaire`.`id_opp` = `interface`.`opportunite`.`id`)) left join `interface`.`actions` on (`interface`.`opportunite`.`id` = `interface`.`actions`.`opp`)) left join `interface`.`users` on (`interface`.`actions`.`user` = `interface`.`users`.`id`)) left join `interface`.`groupe_commission` on (
                                                                                   `interface`.`users`.`groupe_commission` =
                                                                                   `interface`.`groupe_commission`.`id`))
                                                                                    left join `interface`.`etat_opp`
                                                                                              on (`interface`.`actions`.`action` = `interface`.`etat_opp`.`id`))
                                                                           where `interface`.`affaire`.`id` = '351381_2019-06-19-21-19-56'
                                                                             and (`interface`.`etat_opp`.`id` = 4 or `interface`.`etat_opp`.`id_p` = 4)
                                                                           order by `interface`.`actions`.`date` desc
                                                                           limit 1) `tab_actions`;

