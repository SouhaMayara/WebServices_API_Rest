create definer = `nginx-sodedif`@`%` view bareme_with_cs as
select `interface`.`bareme_rule`.`id_bareme_ext_version` AS `id_version`,
       `interface`.`bareme_rule`.`formule`               AS `formule`,
       `interface`.`bareme_rule`.`rules`                 AS `rules`,
       `interface`.`bareme_rule`.`priority`              AS `priority`
from (((`interface`.`bareme_rule` left join `interface`.`bareme_ext_version` on (
        `interface`.`bareme_rule`.`id_bareme_ext_version` =
        `interface`.`bareme_ext_version`.`id_version`)) left join `interface`.`bareme_ext` on (
        `interface`.`bareme_ext_version`.`id_bareme_ext` = `interface`.`bareme_ext`.`id`))
         left join `interface`.`bareme_cmp`
                   on (`interface`.`bareme_ext`.`id` = `interface`.`bareme_cmp`.`id_bareme_ext`))
where json_contains(json_query(`interface`.`bareme_cmp`.`gammes`, '$.gammes'), '["12"]')
  and `interface`.`bareme_rule`.`formule` is not null
  and `interface`.`bareme_cmp`.`cmp` = '781337266';

