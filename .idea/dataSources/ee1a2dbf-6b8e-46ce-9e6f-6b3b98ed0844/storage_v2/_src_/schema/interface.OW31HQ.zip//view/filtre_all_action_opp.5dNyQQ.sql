create definer = admin@`%` view filtre_all_action_opp as select `interface`.`actions`.`action`        AS `action`,
                                                                `interface`.`actions`.`user`          AS `user`,
                                                                `interface`.`actions`.`date`          AS `date`,
                                                                `interface`.`users`.`nom`             AS `users_nom`,
                                                                `interface`.`users`.`prenom`          AS `users_prenom`,
                                                                `interface`.`class_etats`.`id`        AS `id`,
                                                                `interface`.`class_etats`.`libele`    AS `class_etats_libele`,
                                                                `interface`.`etat_opp`.`etat`         AS `etat`,
                                                                `interface`.`actions`.`opp`           AS `action_opp`,
                                                                `interface`.`actions`.`date_objectif` AS `date_objectif`,
                                                                `interface`.`actions`.`categorie`     AS `categorie`
                                                         from (((`interface`.`actions` left join `interface`.`users` on (`interface`.`actions`.`user` = `interface`.`users`.`id`)) left join `interface`.`etat_opp` on (`interface`.`actions`.`action` = `interface`.`etat_opp`.`id`))
                                                                  left join `interface`.`class_etats`
                                                                            on (`interface`.`etat_opp`.`classe` = `interface`.`class_etats`.`id`))
                                                         where `interface`.`actions`.`action` is not null
                                                         group by `interface`.`actions`.`action`,
                                                                  `interface`.`actions`.`opp`,
                                                                  `interface`.`actions`.`user`
                                                         union all
                                                         select `interface`.`actions`.`action`        AS `action`,
                                                                `interface`.`actions`.`user`          AS `user`,
                                                                `interface`.`actions`.`date`          AS `date`,
                                                                `interface`.`users`.`nom`             AS `users_nom`,
                                                                `interface`.`users`.`prenom`          AS `users_prenom`,
                                                                `interface`.`class_etats`.`id`        AS `id`,
                                                                `interface`.`class_etats`.`libele`    AS `class_etats_libele`,
                                                                `interface`.`etat_opp`.`etat`         AS `etat`,
                                                                `interface`.`actions`.`opp`           AS `action_opp`,
                                                                `interface`.`actions`.`date_objectif` AS `date_objectif`,
                                                                `interface`.`actions`.`categorie`     AS `categorie`
                                                         from (((`interface`.`actions` left join `interface`.`users` on (`interface`.`actions`.`user` = `interface`.`users`.`id`)) left join `interface`.`etat_opp` on (`interface`.`actions`.`action` = `interface`.`etat_opp`.`id`))
                                                                  left join `interface`.`class_etats`
                                                                            on (`interface`.`etat_opp`.`classe` = `interface`.`class_etats`.`id`))
                                                         where `interface`.`actions`.`action` is null;

