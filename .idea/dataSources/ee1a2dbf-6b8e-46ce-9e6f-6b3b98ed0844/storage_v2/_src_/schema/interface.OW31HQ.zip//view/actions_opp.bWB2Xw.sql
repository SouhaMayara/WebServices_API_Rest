create definer = admin@`%` view actions_opp as
select `interface`.`actions`.`id`          AS `id`,
       `interface`.`actions`.`action`      AS `action`,
       `interface`.`actions`.`opp`         AS `opp`,
       `interface`.`actions`.`pros`        AS `pros`,
       `interface`.`actions`.`user`        AS `user`,
       `interface`.`actions`.`commentaire` AS `commentaire`,
       `interface`.`actions`.`date`        AS `date`,
       `interface`.`actions`.`comm_opp`    AS `comm_opp`
from `interface`.`actions`
order by `interface`.`actions`.`opp`, `interface`.`actions`.`date`;

