create definer = admin@`%` view nouv_users_cat as
select distinct `interface`.`users`.`id`                             AS `id_user`,
                `interface`.`roles_categoryStatus`.`role`            AS `role`,
                `interface`.`users_category_statuts`.`user_category` AS `category`,
                if(`interface`.`users_category_statuts`.`user_type` = 3, 1,
                   if(`interface`.`users_category_statuts`.`user_type` = 1, 0,
                      `interface`.`roles_categoryStatus`.`sup`))     AS `sup`,
                if(`interface`.`users_category_statuts`.`user_visibilite` = 1, 1,
                   `interface`.`roles_categoryStatus`.`visibilite`)  AS `visibilite`
from ((`interface`.`users_category_statuts` join `interface`.`users` on (
        `interface`.`users_category_statuts`.`id_user_category` = `interface`.`users`.`id`))
         join `interface`.`roles_categoryStatus`
              on (`interface`.`users`.`role` = `interface`.`roles_categoryStatus`.`role`))
where `interface`.`users_category_statuts`.`user_category` = `interface`.`roles_categoryStatus`.`category` and
      `interface`.`users_category_statuts`.`user_type` <> 0
   or `interface`.`users_category_statuts`.`user_type` in (1, 3);

