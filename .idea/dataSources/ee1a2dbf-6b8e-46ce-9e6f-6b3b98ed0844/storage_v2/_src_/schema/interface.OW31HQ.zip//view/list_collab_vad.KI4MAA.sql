create definer = admin@`%` view list_collab_vad as
select `interface`.`users`.`id` AS `ordre`, `interface`.`users`.`id` AS `id_users`
from `interface`.`users`
where `interface`.`users`.`role` = 29
  and `interface`.`users`.`active` = 1
order by `interface`.`users`.`id`;

