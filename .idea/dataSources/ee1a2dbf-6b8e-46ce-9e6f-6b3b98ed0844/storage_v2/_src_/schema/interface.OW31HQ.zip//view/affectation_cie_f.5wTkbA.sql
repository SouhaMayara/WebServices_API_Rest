create definer = admin@`%` view affectation_cie_f as
select `interface`.`bareme_ext`.`id_version` AS `id_version`,
       `interface`.`bareme_rule`.`formule`   AS `formule`,
       `interface`.`bareme_rule`.`rules`     AS `rules`,
       `interface`.`bareme_rule`.`priority`  AS `priority`
from ((`interface`.`bareme_cmp` left join `interface`.`bareme_ext` on (`interface`.`bareme_cmp`.`id_bareme_ext` =
                                                                       `interface`.`bareme_ext`.`id`))
         left join `interface`.`bareme_rule`
                   on (`interface`.`bareme_ext`.`id_version` = `interface`.`bareme_rule`.`id_bareme_ext_version`))
where json_contains(json_query(`interface`.`bareme_cmp`.`gammes`, '$.gammes'), '["1"]')
  and `interface`.`bareme_rule`.`formule` is not null;

