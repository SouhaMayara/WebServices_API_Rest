create definer = developperS@`%` view bareme_int_with_cs as
select `interface`.`bareme_int_group_cmp`.`bareme_int_version` AS `bareme_int_version`,
       `interface`.`bareme_rule`.`rules`                       AS `rules`,
       `interface`.`bareme_rule`.`priority`                    AS `priority`,
       `interface`.`bareme_rule`.`hierarchy`                   AS `hierarchy`,
       `interface`.`bareme_rule`.`formule`                     AS `formule`
from ((`interface`.`bareme_int_group_cmp` left join `interface`.`bareme_int` on (
        `interface`.`bareme_int_group_cmp`.`bareme_int` = `interface`.`bareme_int`.`id`))
         left join `interface`.`bareme_rule` on (`interface`.`bareme_int_group_cmp`.`bareme_int_version` =
                                                 `interface`.`bareme_rule`.`id_bareme_int_version`))
where `interface`.`bareme_int_group_cmp`.`cmp` = 307513259
  and `interface`.`bareme_int_group_cmp`.`id_group_commission` = 14
  and json_contains(json_query(`interface`.`bareme_int_group_cmp`.`gammes`, '$.gammes'), '["38"]')
  and `interface`.`bareme_rule`.`hierarchy` is null
  and `interface`.`bareme_rule`.`formule` is not null
order by `interface`.`bareme_rule`.`priority`;

