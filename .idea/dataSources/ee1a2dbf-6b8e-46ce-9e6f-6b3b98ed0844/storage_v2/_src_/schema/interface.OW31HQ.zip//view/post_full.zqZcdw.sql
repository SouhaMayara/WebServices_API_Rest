create definer = admin@`%` view post_full as
select `interface`.`communication_post`.`id`                  AS `post_id`,
       `interface`.`communication_post`.`type_courrier`       AS `post_type_courrier`,
       `interface`.`communication_post`.`sent_from`           AS `post_sent_from`,
       `interface`.`communication_post`.`id_utilisateur`      AS `post_id_utilisateur`,
       `interface`.`communication_post`.`id_ville_dest`       AS `post_id_ville_dest`,
       `interface`.`communication_post`.`postal_code_post`    AS `postal_code_post`,
       `interface`.`communication_post`.`id_opp`              AS `post_id_opp`,
       `interface`.`communication_post`.`id_prospect`         AS `post_id_prospect`,
       `interface`.`communication_post`.`id_affaire`          AS `post_id_affaire`,
       `interface`.`communication_post`.`id_modele`           AS `post_id_modele`,
       `interface`.`modele_post`.`groupe`                     AS `post_groupe_modele`,
       `interface`.`modele_post`.`nom`                        AS `post_nom_modele`,
       `interface`.`communication_post`.`donn_prospect`       AS `post_donn_prospect`,
       `interface`.`communication_post`.`complement_adr_dest` AS `post_complement_adr_dest`,
       `interface`.`communication_post`.`modele_reel`         AS `post_modele_reel`,
       `interface`.`communication_post`.`statut`              AS `post_statut`,
       `libelle_statut`.`libelle`                             AS `post_libelle_statut`,
       `libelle_statut`.`icone`                               AS `post_icone_statut`,
       `interface`.`communication_post`.`subject`             AS `post_subject`,
       `interface`.`communication_post`.`date`                AS `post_date`,
       `interface`.`communication_post`.`date_envoie`         AS `post_date_envoie`,
       `interface`.`communication_post`.`type_envelope`       AS `post_type_envelope`,
       `interface`.`communication_post`.`couleur`             AS `post_couleur`,
       `interface`.`communication_post`.`type_envoie`         AS `post_type_envoie`,
       `interface`.`libelle_post`.`libelle`                   AS `post_nom_type_envoie`,
       `interface`.`communication_post`.`ref_notif`           AS `post_ref_notif`,
       `interface`.`communication_post`.`preuve_code`         AS `post_preuve_code`,
       `interface`.`communication_post`.`preuve_date`         AS `post_preuve_date`,
       `interface`.`communication_post`.`avis_reception`      AS `post_avis_reception`,
       `interface`.`communication_post`.`ar_date`             AS `post_ar_date`,
       `interface`.`communication_post`.`msg_error`           AS `post_msg_error`,
       `interface`.`communication_post`.`preuve_attachement`  AS `post_preuve_attachement`,
       `interface`.`communication_post`.`tarif_courrier`      AS `post_tarif_courrier`,
       `interface`.`communication_post`.`tarif_suppl`         AS `post_tarif_suppl`,
       `interface`.`communication_post`.`file_courrier`       AS `post_file_courrier`,
       `interface`.`communication_post`.`date_livraison`      AS `post_date_livraison`,
       `interface`.`communication_post`.`nbr_page`            AS `post_nbr_page`,
       `interface`.`communication_post`.`statut_envoi`        AS `post_statut_envoi`,
       `libelle_statut_envoi`.`libelle`                       AS `post_libelle_statut_envoi`,
       `libelle_statut_envoi`.`icone`                         AS `post_icone_statut_envoi`,
       `interface`.`communication_post`.`nomprenom_dest`      AS `post_nomprenom_dest`,
       `interface`.`communication_post`.`last_update`         AS `post_last_update`,
       `interface`.`communication_post`.`statut_notif`        AS `post_statut_notif`,
       `interface`.`communication_post`.`bp_compl_ville_dest` AS `post_bp_compl_ville_dest`,
       `interface`.`communication_post`.`bp_compl_ville_exp`  AS `post_bp_compl_ville_exp`,
       `interface`.`communication_post`.`bp_adresse`          AS `post_bp_adresse`,
       `interface`.`communication_post`.`bp_adresse_exp`      AS `post_bp_adresse_exp`,
       `interface`.`communication_post`.`postal_code_exp`     AS `post_postal_code_exp`,
       `interface`.`communication_post`.`id_ville_exp`        AS `post_id_ville_exp`,
       `interface`.`communication_post`.`complement_adr_exp`  AS `post_complement_adr_exp`,
       `interface`.`communication_post`.`nomprenom_exp`       AS `post_nomprenom_exp`,
       `interface`.`communication_post`.`donn_exp`            AS `post_donn_exp`,
       `interface`.`communication_post`.`ville_dest`          AS `post_ville_dest`,
       `interface`.`communication_post`.`ville_exp`           AS `post_ville_exp`,
       `interface`.`communication_post`.`verif_bp_dest`       AS `post_verif_dest`,
       `interface`.`communication_post`.`verif_bp_exp`        AS `post_verif_exp`,
       `interface`.`affaire`.`num_contrat`                    AS `post_num_contrat`,
       `interface`.`affaire`.`id_contrat`                     AS `post_id_contrat`,
       `interface`.`affaire`.`date_creation`                  AS `post_date_creation_affaire`,
       `interface`.`affaire`.`souscription`                   AS `post_souscription_affaire`,
       `interface`.`affaire`.`cmp`                            AS `post_cmp`,
       `interface`.`affaire`.`date_envoi_res`                 AS `post_date_envoi_res`,
       `interface`.`contrat`.`type`                           AS `post_type_affaire`,
       `interface`.`cmp`.`denomination`                       AS `post_denomination`,
       `interface`.`prospects`.`name`                         AS `prospect_name`,
       `interface`.`prospects`.`surname`                      AS `prospect_surname`,
       `interface`.`villes`.`nom_comm`                        AS `post_ville_nom`,
       `villes_exp`.`nom_comm`                                AS `post_ville_nom_exp`,
       `interface`.`users`.`nom`                              AS `post_crateur_name`,
       `interface`.`user_manager`.`id_manager`                AS `post_id_manager`,
       `interface`.`users`.`prenom`                           AS `post_crateur_surname`
from (((((((((((((`interface`.`communication_post` left join `interface`.`prospects` on (
        `interface`.`communication_post`.`id_prospect` =
        `interface`.`prospects`.`id`)) left join `interface`.`opportunite` on (
        `interface`.`communication_post`.`id_opp` =
        `interface`.`opportunite`.`id`)) left join `interface`.`affaire` on (
        `interface`.`communication_post`.`id_affaire` =
        `interface`.`affaire`.`id`)) left join `interface`.`cmp` on (`interface`.`affaire`.`cmp` = `interface`.`cmp`.`siren`)) left join `interface`.`contrat` on (`interface`.`contrat`.`id` = `interface`.`affaire`.`id_contrat`)) left join `interface`.`users` on (
        `interface`.`communication_post`.`id_utilisateur` =
        `interface`.`users`.`id`)) left join `interface`.`villes` on (`interface`.`communication_post`.`id_ville_dest` =
                                                                      `interface`.`villes`.`id`)) left join `interface`.`villes` `villes_exp` on (`interface`.`communication_post`.`id_ville_exp` = `villes_exp`.`id`)) left join `interface`.`user_manager` on (
        `interface`.`communication_post`.`id_utilisateur` =
        `interface`.`user_manager`.`id_users`)) left join `interface`.`modele_post` on (
        `interface`.`communication_post`.`id_modele` =
        `interface`.`modele_post`.`id`)) left join `interface`.`libelle_post` on (
        `interface`.`communication_post`.`type_envoie` =
        `interface`.`libelle_post`.`code`)) left join `interface`.`libelle_post` `libelle_statut_envoi` on (
            `interface`.`communication_post`.`statut_envoi` = `libelle_statut_envoi`.`code` and
            `libelle_statut_envoi`.`id_p` = 17))
         left join `interface`.`libelle_post` `libelle_statut`
                   on (`interface`.`communication_post`.`statut` = `libelle_statut`.`code` and
                       `libelle_statut`.`id_p` = 8))
group by `interface`.`communication_post`.`id`;

