create definer = admin@`%` view structure_statuts_opp as
select `structure_statuts_opp_subquery`.`id_cycle`     AS `id_cycle`,
       `structure_statuts_opp_subquery`.`cycle_de_vie` AS `cycle_de_vie`,
       `structure_statuts_opp_subquery`.`id_service`   AS `id_service`,
       `interface`.`catergorieStatusOpp`.`libele`      AS `service`,
       `structure_statuts_opp_subquery`.`id_statut`    AS `id_statut`,
       `structure_statuts_opp_subquery`.`statut`       AS `statut`,
       `structure_statuts_opp_subquery`.`etats`        AS `etats`,
       `structure_statuts_opp_subquery`.`parent`       AS `parent`,
       `structure_statuts_opp_subquery`.`id_categorie` AS `id_categorie`,
       `structure_statuts_opp_subquery`.`categorie`    AS `categorie`,
       `structure_statuts_opp_subquery`.`visa`         AS `visa`,
       `structure_statuts_opp_subquery`.`id_classe`    AS `id_classe`,
       `structure_statuts_opp_subquery`.`couleur`      AS `couleur`,
       `structure_statuts_opp_subquery`.`icone`        AS `icone`,
       0                                               AS `sorted`
from (`interface`.`structure_statuts_opp_subquery`
         join `interface`.`catergorieStatusOpp`
              on (`structure_statuts_opp_subquery`.`id_service` = `interface`.`catergorieStatusOpp`.`id`))
order by `structure_statuts_opp_subquery`.`parent` desc;

