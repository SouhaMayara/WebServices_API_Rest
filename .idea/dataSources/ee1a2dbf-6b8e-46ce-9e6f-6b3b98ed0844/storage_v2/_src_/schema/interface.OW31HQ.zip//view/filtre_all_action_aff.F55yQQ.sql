create definer = admin@`%` view filtre_all_action_aff as
select `interface`.`actions_dossier`.`action` AS `action`,
       `interface`.`actions_dossier`.`user`   AS `user`,
       `interface`.`actions_dossier`.`date`   AS `date`,
       `interface`.`users`.`nom`              AS `users_nom`,
       `interface`.`users`.`prenom`           AS `users_prenom`,
       `interface`.`class_etats`.`id`         AS `id`,
       `interface`.`class_etats`.`libele`     AS `class_etats_libele`,
       `interface`.`etat_dossier`.`etat`      AS `etat`,
       `interface`.`etat_dossier`.`color`     AS `etat_rdv_color`
from (((`interface`.`actions_dossier` left join `interface`.`users` on (`interface`.`actions_dossier`.`user` = `interface`.`users`.`id`)) left join `interface`.`etat_dossier` on (
        `interface`.`actions_dossier`.`action` = `interface`.`etat_dossier`.`id`))
         left join `interface`.`class_etats` on (`interface`.`etat_dossier`.`classe` = `interface`.`class_etats`.`id`));

