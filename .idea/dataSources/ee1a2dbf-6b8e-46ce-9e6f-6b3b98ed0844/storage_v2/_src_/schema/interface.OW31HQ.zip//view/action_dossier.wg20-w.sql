create definer = admin@`%` view action_dossier as
select `interface`.`actions_dossier`.`id`          AS `id`,
       `interface`.`actions_dossier`.`action`      AS `action`,
       `interface`.`actions_dossier`.`dossier`     AS `dossier`,
       `interface`.`actions_dossier`.`pros`        AS `pros`,
       `interface`.`actions_dossier`.`user`        AS `user`,
       `interface`.`actions_dossier`.`commentaire` AS `commentaire`,
       `interface`.`actions_dossier`.`date`        AS `date`,
       `interface`.`actions_dossier`.`date_reel`   AS `date_reel`,
       `interface`.`users`.`mail`                  AS `mail`,
       `interface`.`etat_dossier`.`color`          AS `color`,
       `interface`.`catergorieStatusDoss`.`icon`   AS `categorie_icon`,
       `interface`.`actions_dossier`.`comm_opp`    AS `comm_opp`,
       `interface`.`class_etats`.`icon`            AS `classe_icon`,
       `interface`.`class_etats`.`color`           AS `classe_color`,
       `interface`.`class_etats`.`libele`          AS `classe_libele`,
       (select `interface`.`histo_affaire`.`id`
        from `interface`.`histo_affaire`
        where `interface`.`histo_affaire`.`id_affaire` = `interface`.`actions_dossier`.`dossier`
          and timestampdiff(MINUTE, `interface`.`histo_affaire`.`date`,
                            `interface`.`actions_dossier`.`date`) between -1 and 1
        order by `interface`.`histo_affaire`.`date`
        limit 1)                                   AS `histo`
from ((((`interface`.`actions_dossier` left join `interface`.`users` on (`interface`.`actions_dossier`.`user` = `interface`.`users`.`id`)) left join `interface`.`etat_dossier` on (
        `interface`.`actions_dossier`.`action` =
        `interface`.`etat_dossier`.`id`)) left join `interface`.`catergorieStatusDoss` on (
        `interface`.`etat_dossier`.`categorie` = `interface`.`catergorieStatusDoss`.`id`))
         left join `interface`.`class_etats` on (`interface`.`etat_dossier`.`classe` = `interface`.`class_etats`.`id`));

