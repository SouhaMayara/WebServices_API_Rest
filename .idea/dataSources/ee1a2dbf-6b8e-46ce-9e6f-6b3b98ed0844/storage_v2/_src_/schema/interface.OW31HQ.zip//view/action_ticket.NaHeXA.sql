create definer = admin@`%` view action_ticket as
select `interface`.`users`.`mail`                         AS `mail`,
       `interface`.`actions_tickect`.`id_ticket`          AS `id_ticket`,
       `interface`.`actions_tickect`.`commentaire`        AS `commentaire`,
       `interface`.`actions_tickect`.`date_action`        AS `date_action`,
       `interface`.`actions_tickect`.`action`             AS `action`,
       `interface`.`actions_tickect`.`commentaire_action` AS `commentaire_action`
from (`interface`.`actions_tickect`
         join `interface`.`users` on (`interface`.`actions_tickect`.`user` = `interface`.`users`.`id`));

