create definer = admin@`%` view action as
select `interface`.`actions`.`id`                AS `id`,
       `interface`.`actions`.`action`            AS `action`,
       `interface`.`actions`.`opp`               AS `opp`,
       `interface`.`actions`.`pros`              AS `pros`,
       `interface`.`actions`.`user`              AS `user`,
       `interface`.`actions`.`commentaire`       AS `commentaire`,
       `interface`.`actions`.`date`              AS `date`,
       `interface`.`users`.`mail`                AS `mail`,
       `interface`.`etat_opp`.`color`            AS `color`,
       `interface`.`catergorieStatusOpp`.`color` AS `categorie_icon`,
       `interface`.`actions`.`comm_opp`          AS `comm_opp`,
       `interface`.`etat_opp`.`classe`           AS `classe`,
       `interface`.`class_etats`.`icon`          AS `classe_icon`,
       `interface`.`class_etats`.`color`         AS `classe_color`,
       `interface`.`class_etats`.`libele`        AS `classe_libele`,
       (select `interface`.`histo_opp`.`id`
        from `interface`.`histo_opp`
        where `interface`.`histo_opp`.`id_opp` = `interface`.`actions`.`opp`
          and `interface`.`histo_opp`.`date` <=
              concat(date_format(`interface`.`actions`.`date`, '%Y-%m-%d %H:%i'), '-59')
          and `interface`.`histo_opp`.`date` >
              concat(date_format(`interface`.`actions`.`date`, '%Y-%m-%d %H:%i'), '-00')
        order by `interface`.`histo_opp`.`date`
        limit 1)                                 AS `histo`,
       `interface`.`actions`.`date_objectif`     AS `date_objectif`
from ((((`interface`.`actions` join `interface`.`users` on (`interface`.`actions`.`user` = `interface`.`users`.`id`)) left join `interface`.`etat_opp` on (`interface`.`actions`.`action` = `interface`.`etat_opp`.`id`)) left join `interface`.`catergorieStatusOpp` on (
        `interface`.`catergorieStatusOpp`.`id` = `interface`.`etat_opp`.`categorie`))
         left join `interface`.`class_etats` on (`interface`.`etat_opp`.`classe` = `interface`.`class_etats`.`id`))
order by `interface`.`actions`.`date`;

