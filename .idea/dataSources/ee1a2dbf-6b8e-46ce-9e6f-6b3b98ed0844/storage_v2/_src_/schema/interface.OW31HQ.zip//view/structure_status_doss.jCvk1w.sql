create definer = admin@`%` view structure_status_doss as
select `structure_status_doss_subquery`.`id_service`   AS `id_service`,
       `interface`.`catergorieStatusDoss`.`libele`     AS `service`,
       `structure_status_doss_subquery`.`id_statut`    AS `id_statut`,
       `structure_status_doss_subquery`.`statut`       AS `statut`,
       `structure_status_doss_subquery`.`etats`        AS `etats`,
       `structure_status_doss_subquery`.`parent`       AS `parent`,
       `structure_status_doss_subquery`.`id_categorie` AS `id_categorie`,
       `structure_status_doss_subquery`.`categorie`    AS `categorie`,
       `structure_status_doss_subquery`.`visa`         AS `visa`,
       `structure_status_doss_subquery`.`id_classe`    AS `id_classe`,
       `structure_status_doss_subquery`.`couleur`      AS `couleur`,
       `structure_status_doss_subquery`.`icone`        AS `icone`,
       0                                               AS `sorted`
from (`interface`.`structure_status_doss_subquery`
         join `interface`.`catergorieStatusDoss`
              on (`structure_status_doss_subquery`.`id_service` = `interface`.`catergorieStatusDoss`.`id`))
order by `structure_status_doss_subquery`.`parent` desc;

