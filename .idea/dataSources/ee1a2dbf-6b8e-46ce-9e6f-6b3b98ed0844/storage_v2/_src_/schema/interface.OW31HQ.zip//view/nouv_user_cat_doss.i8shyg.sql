create definer = admin@`%` view nouv_user_cat_doss as
select distinct `interface`.`users`.`id`                                  AS `id_user`,
                `interface`.`roles_categoryStatus_Doss`.`role`            AS `role`,
                `interface`.`users_category_statuts_doss`.`user_category` AS `category`,
                if(`interface`.`users_category_statuts_doss`.`user_type` = 3, 1,
                   `interface`.`roles_categoryStatus_Doss`.`sup`)         AS `sup`,
                if(`interface`.`users_category_statuts_doss`.`user_visibilite` = 1, 1,
                   `interface`.`roles_categoryStatus_Doss`.`visibilite`)  AS `visibilite`
from ((`interface`.`users_category_statuts_doss` join `interface`.`users` on (
        `interface`.`users_category_statuts_doss`.`id_user_category` = `interface`.`users`.`id`))
         join `interface`.`roles_categoryStatus_Doss`
              on (`interface`.`users`.`role` = `interface`.`roles_categoryStatus_Doss`.`role`))
where `interface`.`users_category_statuts_doss`.`user_category` = `interface`.`roles_categoryStatus_Doss`.`category` and
      `interface`.`users_category_statuts_doss`.`user_type` <> 0
   or `interface`.`users_category_statuts_doss`.`user_type` in (1, 3);

