create definer = developperS@`%` view bareme_frais_with_cs as
select `interface`.`bareme_rule`.`id_bareme_frais_version` AS `id_bareme_frais_version`,
       `interface`.`bareme_rule`.`rules`                   AS `rules`,
       `interface`.`bareme_rule`.`formule`                 AS `formule`
from `interface`.`bareme_rule`
where `interface`.`bareme_rule`.`id_bareme_frais_version` is not null;

