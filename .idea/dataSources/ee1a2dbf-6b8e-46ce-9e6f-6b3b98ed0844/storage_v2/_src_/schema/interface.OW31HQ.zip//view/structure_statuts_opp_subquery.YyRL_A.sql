create definer = admin@`%` view structure_statuts_opp_subquery as
select `interface`.`etat_opp`.`cycle_vie`                                        AS `id_cycle`,
       `interface`.`cycle_de_vie`.`libele`                                       AS `cycle_de_vie`,
       `interface`.`etat_opp`.`id`                                               AS `id_statut`,
       `interface`.`etat_opp`.`etat`                                             AS `statut`,
       `interface`.`class_etats`.`libele`                                        AS `etats`,
       `interface`.`etat_opp`.`id_p`                                             AS `parent`,
       `interface`.`etat_opp`.`categorie`                                        AS `id_categorie`,
       `interface`.`catergorieStatusOpp`.`libele`                                AS `categorie`,
       `interface`.`etat_opp`.`visa`                                             AS `visa`,
       ifnull(`interface`.`etat_opp`.`visa`, `interface`.`etat_opp`.`categorie`) AS `id_service`,
       `interface`.`etat_opp`.`classe`                                           AS `id_classe`,
       `interface`.`class_etats`.`color`                                         AS `couleur`,
       `interface`.`class_etats`.`icon`                                          AS `icone`
from (((`interface`.`etat_opp` join `interface`.`cycle_de_vie` on (`interface`.`etat_opp`.`cycle_vie` = `interface`.`cycle_de_vie`.`id`)) join `interface`.`class_etats` on (`interface`.`etat_opp`.`classe` = `interface`.`class_etats`.`id`))
         join `interface`.`catergorieStatusOpp`
              on (`interface`.`etat_opp`.`categorie` = `interface`.`catergorieStatusOpp`.`id`))
order by `interface`.`etat_opp`.`cycle_vie`, ifnull(`interface`.`etat_opp`.`visa`, `interface`.`etat_opp`.`categorie`);

